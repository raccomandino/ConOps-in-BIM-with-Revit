namespace Module3.Enums;

public enum EntryKey
{
    Data,
    Secrets
}