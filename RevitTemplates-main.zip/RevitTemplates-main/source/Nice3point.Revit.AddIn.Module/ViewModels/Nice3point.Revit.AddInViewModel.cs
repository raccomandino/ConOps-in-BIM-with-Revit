﻿namespace Nice3point.Revit.AddIn.ViewModels;

public sealed class Nice3point.Revit.AddInViewModel : ObservableObject
{
}